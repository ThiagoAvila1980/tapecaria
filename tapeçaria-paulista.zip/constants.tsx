
import React from 'react';
import { Sofa, Armchair, Car, User, Settings, Building2, MessageSquare } from 'lucide-react';
import { Service, GalleryImage } from './types';

export interface Testimonial {
  id: string;
  name: string;
  text: string;
  rating: number;
  role?: string;
}

export const SERVICES: Service[] = [
  {
    id: '1',
    title: 'Reformas de Sofás',
    description: 'Renovação completa de estruturas e tecidos para sofás de todos os estilos.',
    imageUrl: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '2',
    title: 'Almofadas',
    description: 'Personalização e restauração em couro e tecidos originais para veículos de passeio e luxo.',
    imageUrl: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '3',
    title: 'Poltronas',
    description: 'Trabalho artesanal para peças clássicas e modernas, garantindo conforto e durabilidade.',
    imageUrl: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'Cadeiras',
    title: 'Puffs',
    description: 'Confecção sob medida com materiais de alta densidade e design exclusivo para seu ambiente.',
    imageUrl: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: '5',
    title: 'Puffs',
    description: 'Ergonomia e estilo para sua moto, com materiais antiderrapantes e resistentes ao tempo.',
    imageUrl: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&q=80&w=800'
  }
  {
    id: '6',
    title: 'Serviços automotivos',
    description: 'Ergonomia e estilo para sua moto, com materiais antiderrapantes e resistentes ao tempo.',
    imageUrl: 'https://images.unsplash.com/photo-1558981403-c5f9899a28bc?auto=format&fit=crop&q=80&w=800'
  }
];

export const GALLERY: GalleryImage[] = [
  { id: 'g1', url: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=800', alt: 'Nossa Equipe', category: 'work' },
  { id: 'g2', url: 'https://images.unsplash.com/photo-1590247813693-5541d1c609fd?auto=format&fit=crop&q=80&w=800', alt: 'Máquinas Industriais', category: 'machinery' },
  { id: 'g3', url: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=800', alt: 'Fachada da Loja', category: 'facade' },
  { id: 'g4', url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800', alt: 'Detalhe do acabamento', category: 'work' }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Maria Clara Silva',
    text: 'Reformei meu sofá de 10 anos e ele voltou parecendo novo! O acabamento é impecável e o tecido sugerido pela equipe foi perfeito.',
    rating: 5,
    role: 'Cliente Residencial'
  },
  {
    id: 't2',
    name: 'Ricardo Mendonça',
    text: 'Fiz os bancos de couro do meu SUV. Qualidade superior à original de fábrica. Atendimento muito profissional e entrega no prazo.',
    rating: 5,
    role: 'Proprietário de Veículo'
  },
  {
    id: 't3',
    name: 'Ana Paula Oliveira',
    text: 'Excelente trabalho nas cadeiras da minha mesa de jantar. Recomendo a Tapeçaria Paulista para quem busca perfeccionismo.',
    rating: 5,
    role: 'Cliente Residencial'
  }
];

export const CONTACT_WHATSAPP = "5567992931851";
export const INSTAGRAM_URL = "https://www.instagram.com/tapecaria_paulista";
